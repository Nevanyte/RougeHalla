using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using NUnit.Framework.Internal;

static string Hash(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
var cases = new (string method, object[] args)[]
{
    ("CommittedZeroVoidAndMaximumCreditsAreDisplayedWithoutBalanceInference", new object[] { false, 0L }),
    ("CommittedZeroVoidAndMaximumCreditsAreDisplayedWithoutBalanceInference", new object[] { true, 0L }),
    ("CommittedZeroVoidAndMaximumCreditsAreDisplayedWithoutBalanceInference", new object[] { false, 9007199254740991L }),
    ("HttpErrorsStopTheBurstAndNeverBecomeUnknownOrSaved", new object[] { 403 }),
    ("HttpErrorsStopTheBurstAndNeverBecomeUnknownOrSaved", new object[] { 408 }),
    ("HttpErrorsStopTheBurstAndNeverBecomeUnknownOrSaved", new object[] { 429 }),
    ("HttpErrorsStopTheBurstAndNeverBecomeUnknownOrSaved", new object[] { 500 }),
    ("HttpErrorsStopTheBurstAndNeverBecomeUnknownOrSaved", new object[] { 503 }),
    ("TimelineCutCancelsSuccessAndErrorAndRequiresAnExplicitNewBurst", new object[] { false }),
    ("TimelineCutCancelsSuccessAndErrorAndRequiresAnExplicitNewBurst", new object[] { true }),
    ("OwnerChangeHidesTheRowAndFencesBothOldSuccessAndError", new object[] { false }),
    ("OwnerChangeHidesTheRowAndFencesBothOldSuccessAndError", new object[] { true }),
};
var generator = new TestNameGenerator();
var formatted = new List<object>();
foreach (var item in cases)
{
    var method = new MethodWrapper(typeof(StubMethods), item.method);
    var testMethod = new TestMethod(method);
    formatted.Add(new { method = item.method, argumentTypes = Array.ConvertAll(item.args, a => a.GetType().FullName), displayArguments = item.args, fullName = generator.GetDisplayName(testMethod, item.args) });
}
var nunit = "/Users/nevinmckinnon/Documents/Projects/RogueHalla-unity-art/client-unity/UnityProject/Library/PackageCache/com.unity.ext.nunit@031a54704bff/net40/unity-custom/nunit.framework.dll";
var source = "/Users/nevinmckinnon/.codex/tools/rougehalla-ui-settlement-receipt-2026-11-09/contract-inspector/Program.cs";
var proof = new { schema = "nunit-name-format-proof/1", formatter = "NUnit.Framework.Internal.TestNameGenerator.GetDisplayName(TestMethod, object[])", formatterAssembly = nunit, formatterAssemblySha256 = Hash(nunit), stubType = typeof(StubMethods).FullName, stubSourceSha256 = Hash(source), testBodiesInvoked = false, unityApisUsed = false, cases = formatted };
Console.Write(JsonSerializer.Serialize(proof, new JsonSerializerOptions { WriteIndented = true }));

public sealed class StubMethods
{
    public void CommittedZeroVoidAndMaximumCreditsAreDisplayedWithoutBalanceInference(bool isVoid, long credit) { }
    public void HttpErrorsStopTheBurstAndNeverBecomeUnknownOrSaved(int status) { }
    public void TimelineCutCancelsSuccessAndErrorAndRequiresAnExplicitNewBurst(bool error) { }
    public void OwnerChangeHidesTheRowAndFencesBothOldSuccessAndError(bool error) { }
}

